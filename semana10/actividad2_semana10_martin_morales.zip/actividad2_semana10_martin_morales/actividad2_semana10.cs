﻿using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;

namespace actividad2_semana10
{
    class actividad2_semana10
    {
        public static void Main(string[] args)
        {
            string numero1, numero2, numero3, numero4, numero5, numero6, numero7, numero8, siono="si";
            double num1, num2, num3, num4, num5, num6, num7, num8;

            while(siono=="si")
            {
                while(true)
                {
                    Console.WriteLine("Ingresa el primer de los 8 numeros que debes ingresar.");
                    numero1 = Console.ReadLine();
                    if (double.TryParse(numero1, out num1))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el segundo de los 8 numeros que debes ingresar.");
                    numero2 = Console.ReadLine();
                    if (double.TryParse(numero2, out num2))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el tercer de los 8 numeros que debes ingresar.");
                    numero3 = Console.ReadLine();
                    if (double.TryParse(numero3, out num3))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el cuarto de los 8 numeros que debes ingresar.");
                    numero4 = Console.ReadLine();
                    if (double.TryParse(numero4, out num4))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el quinto de los 8 numeros que debes ingresar.");
                    numero5 = Console.ReadLine();
                    if (double.TryParse(numero5, out num5))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el sexto de los 8 numeros que debes ingresar.");
                    numero6 = Console.ReadLine();
                    if (double.TryParse(numero6, out num6))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el septimo de los 8 numeros que debes ingresar.");
                    numero7 = Console.ReadLine();
                    if (double.TryParse(numero7, out num7))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                while(true)
                {
                    Console.WriteLine("Ingresa el octavo de los 8 numeros que debes ingresar.");
                    numero8 = Console.ReadLine();
                    if (double.TryParse(numero8, out num8))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
                }
                double [] array = [num1, num2, num3, num4, num5, num6, num7, num8];  
                Console.WriteLine("");
                Console.WriteLine("Numeros ingresados: ");
                Console.WriteLine("");
                foreach (var num in array) Console.WriteLine(num);
                Console.WriteLine();
                
                double suma = num1 + num2 + num3 + num4 + num5 + num6 + num7 + num8;
                Console.WriteLine("La suma de los ocho numeros es de: " +suma);
                Console.WriteLine("");

                double promedio = suma/8;
                Console.WriteLine("El promedio de los 8 numeros es de: " +promedio);

                Console.WriteLine("");
                Console.WriteLine("¿Deseas saber sobre otros 8 numeros?");
                siono = Console.ReadLine();

                siono.Trim().ToLower();
                if(siono.Contains("si"))
                {
                    siono = "si";
                }
                else if(siono.Contains("no"))
                {
                    siono = "no";
                }
            }
        }
    }
}