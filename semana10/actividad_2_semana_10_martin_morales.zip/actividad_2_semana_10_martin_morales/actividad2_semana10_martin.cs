﻿using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography.X509Certificates;

namespace actividad2_semana10
{
    class actividad2_semana10
    {
        public static void Main(string[] args)
        {
            string siono="si";
            double [] numero = new double [9];  
            double num = 0, suma = 0;

            while(siono=="si")
            {
                for(int i = 1; i <= 8; i++)
                {
                    while(true)
                {
                    Console.WriteLine("Ingresa el numero " +i +" de los 8 numeros que debes ingresar.");
                    if (double.TryParse(Console.ReadLine(), out num))
                    {
                        numero[i] = num;
                        suma += numero[i];
                        break;
                    }
                    else
                    {
                        i--;
                        Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                    }
                    break;
                }
                }
                Console.WriteLine("Los numeros ingresados son: ");
                foreach (var numeros in numero) Console.WriteLine(numeros);
                Console.WriteLine();
                Console.WriteLine("La suma de los ocho numeros es de: " +suma);
                double promedio = suma / 8;
                Console.WriteLine("El promedio de los 8 numeros es de: " +promedio);
                while(true)
                {
                Console.WriteLine("¿Deseas saber sobre otros 8 numeros?");
                siono = Console.ReadLine();

                siono.Trim().ToLower();
                if(siono.Contains("si"))
                {
                    siono = "si";
                    break;
                }
                else if(siono.Contains("no"))
                {
                    siono = "no";
                    break;
                }
                else
                {
                    Console.WriteLine("Dato invalido. Ingrese si o no.");
                }
                }
            }
        }
    }
}