﻿public class estudiante
{
    public string Nombre;
    public int Edad;
    public string Carrera;
    public string Carnet;
    public double NotaAdmision;
    estudiante(string Nombre, int Edad, string Carrera, string Carnet, double NotaAdmision)
    {
        this.Nombre = Nombre;
        this.Edad = Edad;
        this.Carrera = Carrera;
        this.Carnet = Carnet;
        this. NotaAdmision = NotaAdmision;
    }
    public void MostrarResumen()
    {
        Console.WriteLine("DATOS DEL ESTUDIANTE");Console.WriteLine("");
        Console.WriteLine("Nombre: " +this.Nombre +"    Edad: " +this.Edad);Console.WriteLine("");
        Console.WriteLine("Carrera: " +this.Carrera +"  Carnet: " +this.Carnet);Console.WriteLine("");
        Console.WriteLine("Nota de Admision: "  +this.NotaAdmision);
    }
    public void PuedeMatricular()
    {
        bool matriculacion = false;
        if(this.NotaAdmision >= 75 && this.Carnet.EndsWith("2025"))
        {
            matriculacion = true;
            Console.WriteLine("Es apto para matricularse");
        }
        else
        {
            matriculacion = false;
            Console.WriteLine("No es apto para matricularse");
        }
    }
    public static void Main(string[] args)
    {
        string nombre;
        int edad;
        string carrera;
        string carnet;
        double notaAdmision;
        Console.WriteLine("Ingrese su nombre completo: ");Console.WriteLine("");
        nombre = Console.ReadLine();Console.WriteLine("");
        Console.WriteLine("Ingrese su edad: ");Console.WriteLine("");
        edad = Convert.ToInt32(Console.ReadLine());Console.WriteLine("");
        Console.WriteLine("Ingrese su carrera: ");Console.WriteLine("");
        carrera = Console.ReadLine();Console.WriteLine("");
        Console.WriteLine("Ingrese su No. de carnet: ");Console.WriteLine("");
        carnet = Console.ReadLine();Console.WriteLine("");
        Console.WriteLine("Ingrese su nota de admision");Console.WriteLine("");
        notaAdmision = Convert.ToInt32(Console.ReadLine());Console.WriteLine("");
        estudiante datos = new estudiante(nombre, edad, carrera, carnet, notaAdmision);
        datos.MostrarResumen();
        datos.PuedeMatricular();
    }
}