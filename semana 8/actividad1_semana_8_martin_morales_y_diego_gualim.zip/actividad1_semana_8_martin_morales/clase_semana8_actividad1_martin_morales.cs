﻿using System.Data.Common;

namespace semana_8
{
    class semana_8
    {
        public static void Main(string[] args)
        {
            string validacion;
            int numero;
            while (true)
            {
                Console.WriteLine("Ingresa un numero entero: ");
                validacion = Console.ReadLine();
                if (int.TryParse(validacion, out numero) && numero >= 0)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato inválido. Inténtalo de nuevo.");
                }
            }
            int factorial = CalcularFactorial(numero);
            Console.WriteLine($"El factorial del numero: {numero} es: {factorial}");
        }
        public static int CalcularFactorial(int numero)
        {
            if(numero == 0)
            {
                return 1;
            }
            else
            {
                int factorial = 1;
                for (int i = 1; i <= numero; i++)
                {
                    factorial *= i;
                }
                return factorial;
            }
        }     
    }
}

