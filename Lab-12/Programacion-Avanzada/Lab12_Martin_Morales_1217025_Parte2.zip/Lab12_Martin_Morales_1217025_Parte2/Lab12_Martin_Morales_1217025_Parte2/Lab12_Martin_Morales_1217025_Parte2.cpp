#include <iostream>
#include <string>
using namespace std;

struct Cliente 
{
    int numeroTurno;
    int tiempoAtencion;
};

class Cola 
{
private:

    Cliente datos[100]; 
    int frente;
    int final;
    int contador;
    int capacidad;

public:

    Cola(int capacidadMax = 100) 
    {
        frente = 0;
        final = -1;
        contador = 0;
        capacidad = capacidadMax;
    }

    bool isEmpty() 
    {
        return contador == 0;
    }

    bool isFull() 
    {
        return contador == capacidad;
    }

    void enqueue(Cliente c) 
    {
        if (isFull()) 
        {
            cout << "Error: la cola esta llena.\n" << endl;;
            return;
        }
        final = (final + 1) % capacidad;
        datos[final] = c;
        contador++;
    }

    Cliente dequeue() 
    {
        if (isEmpty()) 
        {
            cout << "Error: la cola esta vacia.\n" << endl;
            Cliente vacio = { -1, 0 };
            return vacio;
        }
        Cliente temp = datos[frente];
        frente = (frente + 1) % capacidad;
        contador--;
        return temp;
    }

    Cliente front() {
        if (isEmpty()) {
            Cliente vacio = { -1, 0 };
            return vacio;
        }
        return datos[frente];
    }
};

int main()
{
    Cola cola;
    int n;

    cout << "=== SIMULACION BANCO URL ===\n\n";
    cout << "Ingrese la cantidad de clientes que llegaran: ";
    cin >> n;

    for (int i = 1; i <= n; i++) 
    {
        Cliente c;
        c.numeroTurno = i;
        cout << "\nTiempo de atencion para el cliente: " << i << " (en minutos): ";
        cin >> c.tiempoAtencion;
        cola.enqueue(c);
    }

    cout << "\n=== INICIANDO ATENCION DE CLIENTES ===\n";
    int tiempoTotal = 0;
    int tiempoAcumulado = 0;

    while (!cola.isEmpty()) 
    {
        Cliente c = cola.dequeue();
        cout << "\nAtendiendo cliente: " << c.numeroTurno
            << " (tiempo: " << c.tiempoAtencion << " min)"
            << " || Espero: " << tiempoAcumulado << " min" << endl;

        tiempoAcumulado += c.tiempoAtencion;
        tiempoTotal += c.tiempoAtencion;
    }

    cout << "\n=== RESULTADOS FINALES ===\n";
    cout << "\nTiempo total de atencion: " << tiempoTotal << " minutos\n";

    return 0;
}
