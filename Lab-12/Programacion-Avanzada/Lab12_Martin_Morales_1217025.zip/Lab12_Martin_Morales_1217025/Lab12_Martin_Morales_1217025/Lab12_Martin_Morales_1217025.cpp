﻿#include <iostream>
#include <string>
using namespace std;

class Pila {
private:

    char datos[100];
    int tope;

public:

    Pila() { tope = -1; }

    void push(char c) {
        if (tope < 99) {
            datos[++tope] = c;
        }
        else {
            cout << "Error: pila llena\n";
        }
    }

    void pop() {
        if (tope >= 0) {
            tope--;
        }
        else {
            cout << "Error: pila vacía\n";
        }
    }

    char top() {
        if (tope >= 0)
            return datos[tope];
        else
            return '\0';
    }

    bool IsEmpty() {
        return tope == -1;
    }
};

int main() {
    Pila pila;
    string expresion;

    cout << "=== INGRESA LA OPERACION CON PARENTESIS ===\n\n";
    getline(cin, expresion);

    bool balanceado = true;

    for (int i = 0; i < expresion.size(); i++) {
        char c = expresion[i];

        if (c == '(') {
            pila.push(c);
        }
        else if (c == ')') {
            if (pila.IsEmpty()) {
                cout << "Error: parentesis de cierre sin apertura en posicion " << i << endl;
                balanceado = false;
                break;
            }
            else {
                pila.pop();
            }
        }
    }

    if (balanceado && pila.IsEmpty()) {
        cout << "\nExpresion balanceada" << endl;
    }
    else if (balanceado && !pila.IsEmpty()) {
        cout << "\nError: faltan paréntesis de cierre" << endl;
    }

    return 0;
}