﻿namespace semana9actividad1
{
    class semana9actividad1
    {
        static void Main(string[] args)
        {
            int n, i = 2; string continuar = "si";
            while(continuar == "si")
            { i=2;
            Console.WriteLine("Ingrese un entero de maximo 6 digitos para determinar si es primo.");
            string numero = Console.ReadLine();
            while(true)
            {
                if(int.TryParse(numero, out n) && n < 1000000 && n > -1000000)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Dato invalido. Por favor intenta otra vez.");
                    Console.WriteLine("Ingrese un entero de maximo 6 digitos para determinar si es primo.");
                    numero = Console.ReadLine();
                }
            }
            while (n % i != 0)
            {
                i++;
            }
    
            if (i == n)
            {
                Console.WriteLine("Es primo");
            }
            else
            {
                Console.WriteLine("No es primo");
            }
            Console.WriteLine("¿Quieres saber sobre otro numero?");
            continuar = Console.ReadLine();
            while(true)
            {
            continuar.Trim().ToLower();
            if(continuar.Contains("no"))
            {
                continuar = "no";
            }          
            if(continuar.Contains("si"))
            {
                continuar = "si";
            }
            if(continuar == "si")
            {
                break;
            }
            if(continuar == "no")
            {
                break;
            }
            else if(continuar != "si" && continuar != "no")
            {
                Console.WriteLine("Dato invalido. Por favor intenta otra vez.");
                Console.WriteLine("¿Quieres saber sobre otro numero?");
                continuar = Console.ReadLine();
            }
            }}
        }
    }
}