﻿using System.Net;

namespace ProyectoPrecalculo
{
    class ProyectoPrecalculo
    {
        // Este es el Main el metodo principal donde se van aoperar todos los metodos, en este se pide el caso a resolver y se le pide al usuario que ingrese los datos necesarios para resolver el caso.   
        public static void Main(string[] args)
        {
            string opcion; int numero = 0; double a, b, c, A = 0, B = 0, C = 0;
            Console.WriteLine("Calculadora Trignometrica\n");
            Console.WriteLine("Ingresa que caso quieres resolvern\n\n1. LAL\n2. ALA\n3. AAL\n4. LAA\n5. LLA\n6. LLL\n7. ALL\n");
            opcion = Console.ReadLine()!;

            while(true)
            {
                if(int.TryParse(opcion, out numero) && numero <=7 && numero >= 1)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("\nEl valor ingresado no es valido, intentelo de nuevo.");
                    opcion = Console.ReadLine()!;
                }
            }

            ProyectoPrecalculo.Triangulo();

            switch(numero)
            {
                case 1:
                    Console.WriteLine("\nIngresa el lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo C\n");
                    C = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado b\n");
                    b = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    LAL(a, b, C);
                    break;
                case 2:
                    Console.WriteLine("\nIngresa el angulo B\n");
                    B = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo C\n");
                    C = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    ALA(B, a, C);
                    break;
                case 3:
                    Console.WriteLine("\nIngresa el angulo B\n");
                    B = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo C\n");
                    C = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado b\n");
                    b = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    AAL(B, C, b);
                    break;
                case 4:
                    Console.WriteLine("\nIngresa el lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo B\n");
                    B = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo A\n");
                    A = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    LAA(a, B, A);
                    break;
                case 5:
                    Console.WriteLine("\nIngresa lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa lado b\n");
                    b = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el angulo A\n");
                    A = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    LLA(a, b, A);
                    break;
                case 6:     
                    Console.WriteLine("\nIngresa el lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado b\n");
                    b = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado c\n");
                    c = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    LLL(a, b, c);
                    break;
                case 7:
                    Console.WriteLine("\nIngresa el angulo B\n");
                    B = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado a\n");
                    a = double.Parse(Console.ReadLine()!);
                    Console.WriteLine("\nIngresa el lado b\n");
                    b = double.Parse(Console.ReadLine()!);
                    Convertir(A, B, C);
                    ALL(B, a, b);
                    break;
                default:
                    Console.WriteLine("\nOpcion no valida.");
                    break;
            }
        }
        // Este metodo es para dibujar el triangulo, se hace de esta manera para que se vea mejor en la consola.
        public static void Triangulo()
        {
            Console.WriteLine("         A           ");
            Console.WriteLine("         .           ");
            Console.WriteLine("        . .          ");
            Console.WriteLine("       .   .         ");
            Console.WriteLine("    c .     . b      ");
            Console.WriteLine("     .       .       ");
            Console.WriteLine("    .         .      ");
            Console.WriteLine(" B ............. C   ");
            Console.WriteLine("         a           ");
        }
        // Este metodo es para el primer caso LAL, en el cual se le ingresan los lados a y b y el angulo C, y se calcula el lado c y los angulos A y B.
        public static void LAL(double a, double b, double C)
        {
            double c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2) - (2 * a * b * Math.Cos(C)));
            double A = Math.Asin((a * Math.Sin(C)) / c);
            double B = Math.Asin((b * Math.Sin(C)) / c);    
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo A es: " + A * (180 / Math.PI) + "°");
            Console.WriteLine("El angulo B es: " + B * (180 / Math.PI) + "°");
        }
        // Este metodo es para el segundo caso ALA, en el cual se le ingresan el angulo B, el lado a y el angulo C, y se calcula el lado b y c y el angulo A.
        public static void ALA(double B, double a, double C)
        {
            double A = 180 - (B + C);
            double b = (a * Math.Sin(B)) / Math.Sin(A);
            double c = (b * Math.Sin(C)) / Math.Sin(B);
            Console.WriteLine("El lado b es: " + b);
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo A es: " + A * (180 / Math.PI) + "°");
        }
        // Este metodo es para el tercer caso AAL, en el cual se le ingresan el angulo B, el angulo C y el lado b, y se calcula el lado a y c y el angulo A.
        public static void AAL(double B, double C, double b)
        {
            double A = 180 - (B + C);
            double a = (b * Math.Sin(A)) / Math.Sin(B);
            double c = (b * Math.Sin(C)) / Math.Sin(B);
            Console.WriteLine("El lado a es: " + a);
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo A es: " + A * (180 / Math.PI) + "°");
        }
        // Este metodo es para el cuarto caso LAA, en el cual se le ingresan el lado a, el angulo B y el angulo A, y se calcula el lado b y c y el angulo C.        
        public static void LAA(double a, double B, double A)
        {
            double C = 180 - (A + B);
            double b = (a * Math.Sin(B)) / Math.Sin(A);
            double c = (a * Math.Sin(C)) / Math.Sin(A);
            Console.WriteLine("El lado b es: " + b);
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo C es: " + C * (180 / Math.PI) + "°");
        }
        // Este metodo es para el quinto caso LLA, en el cual se le ingresan los lados a y b y el angulo A, y se calcula el lado c y los angulos B y C.
        public static void LLA(double a, double b, double A)
        {
            double B = Math.Asin((b * Math.Sin(A)) / a);
            double C = 180 - (A + B);
            double c = Math.Sqrt(Math.Pow(a, 2) + Math.Pow(b, 2) - (2 * a * b * Math.Cos(C)));
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo B es: " + B * (180 / Math.PI) + "°");
            Console.WriteLine("El angulo C es: " + C * (180 / Math.PI) + "°");
        }
        // Este metodo es para el sexto caso LLL, en el cual se le ingresan los lados a, b y c, y se calcula los angulos A, B y C.
        public static void LLL(double a, double b, double c)
        {
            double A = Math.Acos((Math.Pow(b, 2) + Math.Pow(c, 2) - Math.Pow(a, 2)) / (2 * b * c));
            double B = Math.Acos((Math.Pow(a, 2) + Math.Pow(c, 2) - Math.Pow(b, 2)) / (2 * a * c));
            double C = Math.Acos((Math.Pow(a, 2) + Math.Pow(b, 2) - Math.Pow(c, 2)) / (2 * a * b));
            Console.WriteLine("El angulo A es: " + A * (180 / Math.PI) + "°");
            Console.WriteLine("El angulo B es: " + B * (180 / Math.PI) + "°");
            Console.WriteLine("El angulo C es: " + C * (180 / Math.PI) + "°");
        }
        // Este metodo es para el septimo caso ALL, en el cual se le ingresan el angulo B y los lados a y b, y se calcula el lado c y los angulos A y C.
        public static void ALL(double B, double a, double b)
        {
            double A = Math.Asin((a * Math.Sin(B)) / b);
            double C = 180 - (A + B);
            double c = (a * Math.Sin(C)) / Math.Sin(A);
            Console.WriteLine("El lado c es: " + c);
            Console.WriteLine("El angulo B es: " + B * (180 / Math.PI) + "°");
            Console.WriteLine("El angulo C es: " + C * (180 / Math.PI) + "°");
        }
        // Este metodo es para convertir los angulos de grados a radianes, ya que las funciones trigonometrica trabajan con radianes.
        public static void Convertir(double A, double B, double C)
        {
            A = A * (Math.PI / 180);
            B = B * (Math.PI / 180);
            C = C * (Math.PI / 180);
        }
    }
}
